# ClearLens Camera (Android source project)

## Features
- Offline camera preview (camera permission required)
- High-quality still capture using CameraX's quality-priority capture mode
- Front/rear camera switching
- Device-supported zoom range (the slider adapts to the selected camera)
- Tap-to-focus
- Torch/flashlight toggle when supported by the selected camera
- Natural, Vivid, Warm, Mono and Cool photo looks applied to captured images
- Photos saved to `Pictures/ClearLens`
- Gallery picker shortcut

## Build
1. Open this folder in Android Studio on a computer with Android SDK Platform 35 installed.
2. Allow Gradle to sync and download the AndroidX CameraX dependencies.
3. Choose **Build > Build APK(s)**.
4. Install the generated debug APK on your Android phone and test camera permission, focus, zoom, flash, filters and photo saving.

## Important limits
- This is source code, not a prebuilt or device-tested APK.
- A successful build and real-phone testing are still required; camera features vary by device.
- Zoom is limited to the selected camera's reported range; digital zoom can reduce detail.
- Filters are applied to the saved photo, not as live preview effects.
- The app does not require internet while taking photos, but the first Gradle build needs internet to download dependencies.
